var shuzu = [];
Page({
  data: {
    lists: [],
  },
  imgchange: function (event) {
    //获取当前item的下标id  通过currentTarget.id
    var id = event.currentTarget.id;
    var that = this
    console.log(id);
    var nums = this.data.lists[id].num;
    // console.log(nums);
    console.log(this.data.lists)

    wx.chooseLocation({
      success: function (res) {
        shuzu[id] = { num: res.name }
        that.setData({
          lists: shuzu
        })
      },
    })


  },

  addPoint() {
    var lists = this.data.lists
    var newData = {};
    lists.push(newData);
    this.setData({
      lists: lists
    })

  }
}) 